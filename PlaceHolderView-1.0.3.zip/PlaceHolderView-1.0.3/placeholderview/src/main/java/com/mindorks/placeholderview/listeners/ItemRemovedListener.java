package com.mindorks.placeholderview.listeners;

/**
 * Created by janisharali on 18/01/17.
 */

public interface ItemRemovedListener {
    void onItemRemoved(int count);
}
