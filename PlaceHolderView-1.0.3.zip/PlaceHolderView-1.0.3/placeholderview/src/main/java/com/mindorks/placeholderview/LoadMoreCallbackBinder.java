package com.mindorks.placeholderview;

/**
 * Created by janisharali on 10/03/18.
 */

public interface LoadMoreCallbackBinder<T> {

    void bindLoadMore(T resolver);
}
